//
//  TimeTimeApp.swift
//  TimeTime
//
//  Created by levin marvyn on 18/02/2025.
//

import SwiftUI

@main
struct TimeTimeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
