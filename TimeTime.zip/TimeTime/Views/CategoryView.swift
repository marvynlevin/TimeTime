import SwiftUI
import Charts

struct CategoryView: View {
    @StateObject private var viewModel = CategoryViewModel()  // Observer le ViewModel
    let graphTypes = ["Barre", "Courbe"]  // Types de graphiques disponibles

    var body: some View {
        NavigationView {
            VStack {
                Image("logoTimeTime")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 200, height: 70)
                    .padding(.vertical, 20)
                
                // Picker pour sélectionner le type de graphique
                Picker("Type de graphique", selection: $viewModel.selectedGraphType) {
                    ForEach(graphTypes, id: \.self) { graph in
                        Text(graph)
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
                .padding()

                // Affichage du graphique en fonction du type sélectionné
                if viewModel.selectedGraphType == "Barre" {
                    Chart(viewModel.timeData) { data in
                        BarMark(
                            x: .value("Temps", data.timeUnit),
                            y: .value("Durée", min(data.duration, 24)) // Limite à 24h max
                        )
                        .foregroundStyle(getColorForCategory(data.category))  // Application de la couleur en fonction de la catégorie
                    }
                    .frame(height: 300)
                    .padding()
                    .chartYAxis {
                        AxisMarks(position: .leading) { value in
                            // Affichage personnalisé des labels sur l'axe des ordonnées
                            AxisValueLabel {
                                if let duration = value.as(Float.self), duration.truncatingRemainder(dividingBy: 2) == 0 {
                                    Text("\(Int(duration))h")
                                }
                            }
                        }
                    }
                }
                
                // Affichage du graphique en courbe
                if viewModel.selectedGraphType == "Courbe" {
                    Chart(viewModel.timeData) { data in
                        LineMark(
                            x: .value("Temps", data.timeUnit),
                            y: .value("Durée", min(data.duration, 24)) // Limite à 24h max
                        )
                        .foregroundStyle(getColorForCategory(data.category))  // Application de la couleur en fonction de la catégorie
                    }
                    .frame(height: 300)
                    .padding()
                    .chartYAxis {
                        AxisMarks(position: .leading) { value in
                            // Affichage personnalisé des labels sur l'axe des ordonnées
                            AxisValueLabel {
                                if let duration = value.as(Float.self), duration.truncatingRemainder(dividingBy: 2) == 0 {
                                    Text("\(Int(duration))h")
                                }
                            }
                        }
                    }
                }

                // Message d'alerte basé sur l'utilisation
                alertMessage()
                    .padding()
                
                Spacer()
            }
            .navigationBarTitle("Temps passé", displayMode: .inline)
        }
    }
    
    // Fonction pour obtenir la couleur basée sur la catégorie
    func getColorForCategory(_ category: AppCategory) -> Color {
        return category.color
    }
    
    // Affiche un message d'alerte en fonction du temps d'utilisation total
    @ViewBuilder
    func alertMessage() -> some View {
        let totalUsage = viewModel.timeData.reduce(0) { $0 + $1.duration }
        
        HStack {
            Image(systemName: "person.fill")
                .resizable()
                .frame(width: 50, height: 50)
                .foregroundColor(Color(hex: "#B64D6E"))
            
            if totalUsage > 180 {
                Text("📱 Aujourd'hui, vous avez été **beaucoup trop** sur votre téléphone ! Essayez de réduire cela.")
                    .font(.body)
                    .foregroundColor(.black)
            } else if totalUsage > 90 {
                Text("📱 Aujourd'hui, vous avez été **un peu trop** sur votre téléphone ! Essayez de faire une pause.")
                    .font(.body)
                    .foregroundColor(.black)
            } else {
                Text("🎉 Bravo ! Votre utilisation du téléphone est bien équilibrée.")
                    .font(.body)
                    .foregroundColor(.black)
            }
        }
    }
}
