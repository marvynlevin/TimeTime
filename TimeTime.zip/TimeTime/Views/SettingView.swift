//
//  ParamView.swift
//  TimeTime
//
//  Created by levin marvyn on 11/03/2025.
//

import SwiftUI

struct SettingView: View {
    var body: some View {
        NavigationView {
            Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
        }
    }
}

#Preview {
    SettingView()
}
