import Foundation

class TimeViewModel: ObservableObject {
    @Published var timeData: [TimeData] = []  // Les données à afficher dans le graphique
    @Published var selectedGraphType: String = "Barre"  // Type de graphique sélectionné
    
    private var timeUsageData: [Time] = []  // Les données brutes

    init() {
        loadTimeData()  // Charger les données au démarrage
        calculateData()  // Calculer les données à afficher
    }
    
    // Charger les données de test (ou de la base de données si nécessaire)
    func loadTimeData() {
        timeUsageData = Time.testData  // Remplacer par des vraies données si nécessaire
        calculateData()  // Recalculer les données après le chargement
    }

    // Calculer les données affichées pour la semaine actuelle
    func calculateData() {
        generateWeeklyData()
    }

    // Générer les données pour la semaine (sans filtrer)
    private func generateWeeklyData() {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        // Récupérer la date d'aujourd'hui
        let currentDate = Date()
        let calendar = Calendar.current
        
        // Regrouper les données par jour de la semaine
        let daysOfWeek = ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"]
        
        let groupedByDay = Dictionary(grouping: timeUsageData, by: { timeEntry -> String? in
            if let date = dateFormatter.date(from: timeEntry.date) {
                let dayIndex = Calendar.current.component(.weekday, from: date) - 2
                return dayIndex >= 0 ? daysOfWeek[dayIndex] : daysOfWeek[6] // Ajustement pour Dimanche
            }
            return nil
        })
        
        // Calculer le total d'heures pour chaque jour de la semaine
        timeData = daysOfWeek.compactMap { day in
            let totalHours = groupedByDay[day]?.reduce(0) { $0 + $1.timeInHours } ?? 0
            return TimeData(timeUnit: day, duration: totalHours)
        }
    }
}

// Struct pour contenir les données formatées pour l'affichage dans la vue
struct TimeData: Identifiable {
    var id = UUID()
    var timeUnit: String
    var duration: Float
    
    var formattedDuration: String {
        return "\(Int(duration))h"
    }
}
